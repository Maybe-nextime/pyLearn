#dict 无序
d = {'Michael': 95, 'Bob': 75, 'Tracy': 85}