# 判断对象类型,使用type()函数:
type(123)
# <class 'int'>
# type()函数返回对应的Class类型,
# type(123) == type(456)
# True

# 判断对象是否是函数?使用types模块中定义的变量
import types
def fn():
    pass
type(fn) == types.FunctionType
type(abs) == types.BuiltinFunctionType
type(lambda x: x) == types.LambdaType
type((x for x in range(10))) == types.GeneratorType

# isinstance() -- 一个对象是否是某种类型

# 判断一个变量是否是某些类型中的一种
isinstance([1,2,3],(list,tuple))

# dir() 获得一个对象的所有属性和方法,可以用dir(),它返回一个包含字符串的list
dir('ABC')

# getattr()、setattr()以及hasattr()，我们可以直接操作一个对象的状态

class MyObject(object):
    def __init__(self):
        self.x = 9
    def power(self):
        return self.x * self.x
obj = MyObject()

hasattr(obj,'x')
#obj.x -- 9

# 传入default参数,不存在即404
getattr(obj,'z',404)

# 获得对象的方法
hasattr(obj,'power')
fn = getattr(obj,'power')
fn()

