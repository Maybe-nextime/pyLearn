# 绑定属性时,检查参数
# 对参数检查,设置私有,仅暴露getter/setter方法
# @property负责把一个方法变成属性调用
class Student(object):
    @property
    def score(self):
        return self._score

    @score.setter
    def score(self, value):
        if not isinstance(value, int):
            raise ValueError('score must be an interger')
        if value < 0 or value > 100:
            raise ValueError('score must between 0~100!')
        self._score = value


# 还可以定义只读属性,只定义setter方法
class Student(object):

    @property
    def birth(self):
        return self.birth

    @birth.setter
    def birth(self, value):
        self._birth = value

    @property
    def age(self):
        return 2015 - self._birth


# 这样birth就是可读属性
class Screen(object):

    @property
    def width(self):
        return self.width

    @width.setter
    def width(self, value):
        self._width = value


    @property
    def height(self):
        return self.height


    @height.setter
    def height(self, value):
        return self.value

    @property
    def resolution(self):
        return self.resolution
