class Student(object):
    name = 'Student' # 类属性
    def __init__(self,name):
        self.name = name #实例变量

s = Student('Bob')
s.score = 90

# 因为相同名称的实例属性将屏蔽掉类属性，但是当你删除实例属性后，再使用相同的名称，访问到的将是类属性

# 给实例绑定方法
def set_age(self,age):
    self.age = age

from types import MethodType
s.set_age = MethodType(set_age,s) # 给实例绑定一个方法

# 给实例绑定方法,对另一个实例不起作用,所以可以给class绑定方法
def set_score(self,score):
    self.score = score

Student.set_score = set_score

# 所有实例均可用

# 使用__slots__
# 想要限制实例属性,允许对Student添加name和age属性
class Student(object):
    __slots__ = ('name','age') # 用tuple定义允许绑定的属性名称

# __slots__要注意,__slots__定义的属性仅对当前类实例起作用,对继承的子类是不起作用的
class GraduateStudent(Student):
    pass
g = GraduateStudent()
g.score = 9999
