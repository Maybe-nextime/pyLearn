class Animal(object):
    def run(self):
        print('Animal is running')

# 继承
class Dog(Animal):
    pass

class Cat(Animal):
    pass

# 继承子类获得了父类的全部功能,由于Animal实现了run()方法,Dog和Cat作为子类,自动拥有了run()方法:
dog = Dog()
dog.run()
# Animal is running...
class Dog(Animal):
    def run(self):
        print('Dog is running...')
# 子类的run()覆盖了父类的run()
c = Dog() # c是Dog类型

# isinstance(c,Dog) --True
# isinstance(c,Animal) -- True
# 多态:由运行时该对象的确切类型决定，这就是多态真正的威力：调用方只管调用，不管细节，而当我们新增一种Animal的子类时，只要确保run()方法编写正确，不用管原来的代码是如何调用的。这就是著名的“开闭”原则。

