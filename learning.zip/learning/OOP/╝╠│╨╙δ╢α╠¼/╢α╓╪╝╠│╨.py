class Animal(object):
    pass

# 大类: 哺乳
class Mammal(Animal):
    pass

class Runnable(object):
    def run(self):
        print('Running...')

class Flyable(object):
    def fly(self):
        print('Flying...')

# 多重继承
class Dog(Mammal,Runnable):
    pass