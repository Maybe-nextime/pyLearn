# OOP 对象包含数据和操作数据的方法
class Student(object):
    def __init__(self,name,score):
        self.name = name
        self.score= score

    def print_score(self):
        print('%s: %s' %(self.name,self.score))

# 在__init__方法内部，就可以把各种属性绑定到self，因为self就指向创建的实例本身
# python 允许对象另外赋值

# 访问限制:外部代码能自由地修改实例的属性
# _xxx __xxx 是私有变量

class Student(object):
    def __init__(self,name,score):
        self._name = name
        self._score= score

    def print_score(self):
        print('%s: %s' %(self._name,self._score))

# 私有后外部代码要获取怎么办?get/set 方法
    def get_name(self):
        return self._name
    def get_score(self):
        return self._score
    def set_name(self, name):
        self.name = name

# __xxx 也不是不能访问,通过 _Student__name访问__name变量
# TODO 检查参数有效性
