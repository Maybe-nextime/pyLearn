# 一个函数接收另一个函数作为参数,称之为高阶函数
# 函数式编程就是这样高度抽象
# e.g
def add(x,y,f):
    return f(x) + f(y)
print(add(-5,6,abs))
