# python 内建的filter()函数用于过滤序列
# filter根据返回值是True还是False决定保留,丢弃

# 序列中删掉空字符串
def not_empty(s):
    return s and s.strip()


list(filter(not_empty, ['A', '', 'B', None, 'C', ' ']))


# filter返回Iterator,强迫filter()完成计算,需要用list()函数获得所有结果并返回list

# 用filter 计算素数
# 埃氏筛法
# 2开始的所有自然数,构造一个序列,筛掉2和2的倍数
# 3开始,筛掉3和3的倍数
# 5开始,不断筛下去,能得到所有素数
# 函数是有限的,生成器是无限的.
def _odd_iter():
    n = 1
    while True:
        n = n + 2
        yield n
def _not_divisible(n):
    return lambda x: x % n > 0
def primes():
    yield 2
    it = _odd_iter()
    while True:
        n = next(it)
        yield n
        it = filter(_not_divisible(n),it) # 构造新序列


# 打印1000以内素数
for n in primes():
    if n < 1000:
        print(n)
    else:
        break

# filter判断回文数
def is_palindrom(n):
    return str(n) == str(n)[::-1]