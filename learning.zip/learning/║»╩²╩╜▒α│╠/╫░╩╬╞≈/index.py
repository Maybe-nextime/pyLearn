# 由于函数也是一个对象，而且函数对象可以被赋值给变量,通过变量也能调用函数
# def now():
#     print("2021-02-23")
# f = now
# f()
# print(f.__name__)

# 代码运行期间动态增加功能的方式，称之为“装饰器”（Decorator）
# 本质上,decorator接收函数作为参数,就是一个返回函数的高阶函数
def log(func):
    def wrapper(*args,**kw):
        print('call %s():' % func.__name__)
        return func(*args, **kw)
    return wrapper

# 借助Python的@语法,把decorator置于函数定义处
@log
def now():
    print('2021-02-23')
now()

# now = log(now)
# 由于log()是一个decorator,返回一个函数,虽然原来的now()仍然存在,但是同名的now变量指向新的函数
# wrapper()函数的参数定义是(*args, **kw)，因此，wrapper()函数可以接受任意参数的调用。
def log(text):
    def decorator(func):
        def wrapper(*args, **kw):
            print('%s %s():' %(text,func.__name__))
            return func(*args, **kw)
        return wrapper
    return decorator
# TODO 复习