# 函数作为返回值
# 高阶函数除了可以接受函数作为参数外，还可以把函数作为结果值返回
# 一般的求和函数
def calc_sum(*args):
    ax = 0
    for n in args:
        ax = ax +n
    return ax

# 返回求和的函数
# 内部的sum函数引用外部lazy_sum的参数和局部变量,相关参数和变量都保存在返回的函数中,这种称为闭包(Closure)
def lazy_sum(*args):
    def sum():
        ax = 0
        for n in args:
            ax = ax + n
        return ax
    return sum

f = lazy_sum(1,3,5,7,9)
# 直接调用f会报错
print(f())

# 当一个函数返回了一个函数后，其内部的局部变量还被新函数引用
# 返回的函数并没有立刻执行，而是直到调用了f()才执行
def count():
    fs = []
    for i in range(1,4):
        def f():
            return i*i
        # list添加函数的返回
        fs.append(f)
    return fs
f1,f2,f3 = count()
# 都是9,原因在于返回的函数引用了变量i,但函数并非立即执行
# 返回闭包时牢记一点：返回函数不要引用任何循环变量，或者后续会发生变化的变量。

