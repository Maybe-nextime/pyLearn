def f(x):
    return x*x
lambda x:x * x
# 只有一个表达式,不用写return
f = lambda x:x * x
f(5)