import math

def move(x,y,step,angle=0):
    nx = x + step * math.cos(angle)
    ny = y + step * math.sin(angle)
    return nx,ny

def add_end(L=[]):
    L.append('END')
    return L

# 可变参数自动组装为tuple
def calc(*numbers):
    sum = 0
    for n in numbers:
        sum = sum + n*n
    return sum

# 关键字参数自动组装dict
def person(name,age,**kw):
    print('name:',name,'age',age,'other',kw)
person('Adam',45,gender='M',job='engineer')