def nop():
    pass #pass就是什么都不做,占位符