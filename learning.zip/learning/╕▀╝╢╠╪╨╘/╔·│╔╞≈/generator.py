# 在python中,边循环边计算的机制,称为生成器
# 如果函数定义中包含yield关键字,那它就是个generator
# 函数和generator的执行流程不一样,函数遇到return或者执行到最后一行就返回;变成generator的函数,在每次调用next()时执行,遇到yield语句返回,再次执行,从上次返回的yield语句处继续
# 区分generator和函数
L = [x * x for x in range(10)] -- 列表生成式
g = (x * x for x in range(10)) -- 生成器
next(g),计算下一个元素值
