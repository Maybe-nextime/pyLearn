# 可以被next()函数调用并不断返回下一个值得对象称为迭代器 Iterator
from collections.abc import Iterator
a = isinstance((x for x in range(10)), Iterator)
print(a)

# iter()函数将Iterable对象转为Iterator对象