# isinstance() 判断对象是否是Iterable 对象
from collections.abc import Iterable
print(isinstance([],Iterable))

