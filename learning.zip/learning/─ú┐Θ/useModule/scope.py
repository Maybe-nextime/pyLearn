# 正常的函数和变量名是公开的(public)
# 类似 __xxx__ 这样的变量是特殊变量
# _xxx 和 __xxx这样的函数或变量就是非公开,不该被直接引用
def _private1(name):
    pass
def _private2(name):
    pass

def greeting(name):
    if (True):
        return _private1(name)
    else:
        return _private2(name)
        