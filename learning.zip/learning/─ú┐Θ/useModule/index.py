#!/usr/bin/env python3
# -*- coding: utf-8 -*-

' a test module '

__author__ = 'ry Zhang'

import sys
# 利用sys变量,使用sys模块的所有功能
# sys模块的argv变量,用list储存命令行所有参数
def test():
    args = sys.argv
    if len(args) == 1:
        print('Hello, world')
    elif len(args) == 2:
        print('Hello, %s!' % args[1])
    else:
        print('Too many args')

# 模块通过命令行运行时执行一些额外的代码
if __name__ == '__main__':
    test()
