s = input('birth:')
birth = int(s)
if birth < 2000:
    print('00前')
else:
    print('00后')