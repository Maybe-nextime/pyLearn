# 循环0-100
# sum = 0
# for x in range(101):
#     sum += x
# print(sum)

# continue 跳过循环
n=0
while n < 10:
    n = n+1
    if n%2==0:
        continue # 跳过这次循环
    print(n)